BT TRÊN LỚP - ACTIVITY

Nội dung đúng yêu cầu:
- App gồm 2 Activity: MainActivity và DetailActivity.
- MainActivity có button chuyển sang DetailActivity bằng Intent.
- DetailActivity có button quay lại MainActivity bằng Intent.
- Có AndroidManifest khai báo cả 2 Activity.

Cách mở:
1. Giải nén file ZIP.
2. Mở thư mục BT_Tren_Lop_Activity bằng Android Studio.
3. Chờ Gradle Sync hoàn tất.
4. Chọn máy ảo hoặc điện thoại Android.
5. Run app.

Package:
com.example.bttrenlopactivity
